package com.jdbc;
import java.sql.*;

public class JDBCExample {

   static final String DB_URL = "jdbc:mysql://localhost:3306/employee";
   static final String USER = "root";
   static final String PASS = "root";

   public static void main(String args[]) {
      try{
         Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
         Statement stmt = conn.createStatement();
         stmt.execute("INSERT INTO emp VALUES(101, 'Jenny', 25, 10000), (102, 'Jacky', 30, 20000), (103, 'Joe', 20, 40000), (104, 'John', 40, 80000), (105, 'Shameer', 25, 90000)");
         System.out.println("\n----- Successfully inserted into table emp ----\n\n");
         System.out.println("Displaying records from emp table, showing inserted values\n");
         ResultSet rs = stmt.executeQuery("select * from emp");

         System.out.println("empcode  " + "empname " + "\tempage " + "\tesalary ");
         System.out.println("-------------------------------------------");
         while(rs.next()){
            System.out.println(rs.getInt(1) + "\t " + rs.getString(2) + "\t\t " + rs.getInt(3) + "\t " + rs.getInt(4));
         }
      }catch(SQLException e){
         e.printStackTrace();
      }
   }
}
